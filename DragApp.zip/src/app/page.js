"use client";
import { useState } from "react";
import DraggableList from "../app/components/DraggableList";

const initialItems = [
  {
    id: "1",
    title: "Scotland Island",
    subtitle: "Sydney, Australia",
    image: "/path/to/img1.jpg",
  },
  {
    id: "2",
    title: "The Charles Grand Brasserie & Bar",
    subtitle: "Lorem ipsum, Dolor",
    image: "/path/to/img2.jpg",
  },
  {
    id: "3",
    title: "Bridge Climb",
    subtitle: "Dolor, Sit omet",
    image: "/path/to/img3.jpg",
  },
  {
    id: "4",
    title: "Scotland Island",
    subtitle: "Sydney, Australia",
    image: "/path/to/img4.jpg",
  },
  {
    id: "5",
    title: "Clam Bar",
    subtitle: "Etcetera veni, Vidi vici",
    image: "/path/to/img5.jpg",
  },
  {
    id: "6",
    title: "Vivid Festival",
    subtitle: "Sydney, Austraila",
    image: "/path/to/img6.jpg",
  },
];
export default function Home() {
  const [items, setItems] = useState(initialItems);

  const handleChangeOrder = (item, newPos) => {
    setItems((prevItems) => {
      const index = prevItems.findIndex((m) => m.id === item.id);

      prevItems.splice(index, 1);
      prevItems.splice(newPos > index ? newPos - 1 : newPos, 0, item);

      return prevItems;
    });
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex">
        <div className="w-[570px] pr-4">
          <h1 className="text-2xl font-bold mb-4">Draggable List</h1>
          <DraggableList items={items} onChangeOrder={handleChangeOrder} />
        </div>
      </div>
    </div>
  );
}
