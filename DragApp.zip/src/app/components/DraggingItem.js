import React, { useEffect, useRef } from "react";

const DraggingItem = ({ isDragging, item, pos }) => {
  if(!isDragging) return <></>;
  const divRef = useRef();

  useEffect(() => {
    if(!isDragging) return;

    divRef.current.style.top = pos.y + "px";
    divRef.current.style.left = pos.x + "px";
    console.log(divRef.current.style);
  }, [pos]);

  return (
    <div
      ref={divRef}
      className={`absolute p-[16px] flex items-center w-max bg-white border-solid border-[1px] border-[rgba(0, 0, 0, 0.1)] rounded-[8px] shadow-lg`}
    >
      <img
        className="w-[32px] h-[32px] rounded-[4px] mr-[12px]"
        src={item.image}
      />
      <div className="text-[17px] font-medium leading-[22px] text-nowrap">{item.title}</div>
    </div>
  );
};

export default DraggingItem;
