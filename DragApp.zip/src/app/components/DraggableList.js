import React, { useRef, useState } from "react";
import DraggingItem from "./DraggingItem";

const DraggableList = ({ items, setItems, onChangeOrder }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [draggingItem, setDraggingItem] = useState(null);
  const [draggingPosition, setDraggingPosition] = useState(null);
  const [pos, setPos] = useState(null);
  const listRef = useRef(null);

  const handleDragStart = (e, item) => {
    setIsDragging(true);
    setDraggingItem(item);

    setPos({
      x: e.clientX - listRef.current.offsetLeft,
      y: e.clientY - listRef.current.offsetTop,
    });
  };
  const handleDragMove = (e) => {
    if (
      e.clientX > listRef.current.offsetLeft &&
      e.clientX < listRef.current.offsetLeft + listRef.current.clientWidth &&
      e.clientY > listRef.current.offsetTop &&
      e.clientY < listRef.current.offsetTop + listRef.current.clientHeight
    ) {
      const tx = e.clientX - listRef.current.offsetLeft;
      const ty = e.clientY - listRef.current.offsetTop;

      setPos({
        x: tx,
        y: ty,
      });
      const height = listRef.current.children[0].clientHeight;
      setDraggingPosition(Math.round(ty / height));
    } else {
      handleDragEnd();
    }
  };
  const handleDragEnd = () => {
    setIsDragging(false);
    setDraggingPosition(null);
    setDraggingItem(null);

    onChangeOrder(draggingItem, draggingPosition);
  };

  return (
    <div
      ref={listRef}
      className={`relative ${isDragging ? "cursor-grabbing" : "cursor-grab"}`}
      onMouseMove={(e) => {
        isDragging && handleDragMove(e);
      }}
      onMouseUp={(e) => {
        isDragging && handleDragEnd(e);
      }}
    >
      {items.map((item) => (
        <div
          key={`drag-id-${item.id}`}
          className={`relative rounded-[12px] ${isDragging ? "" : "hover-effect"} ${
            item.id === draggingItem?.id ? "dragged" : ""
          }`}
        >
          <div
            className={`flex items-center leading-[15px] whitespace-normal px-[40px] py-[20px] select-none`}
            onMouseDown={(e) => {
              !isDragging && handleDragStart(e, item);
            }}
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-[96px] h-[96px] object-cover rounded mr-[24px] rounded-[12px] select-none"
              onDragStart={(e) => {
                e.preventDefault();
              }}
            />
            <div className="flex flex-col">
              <div className="font-medium text-[19px] leading-[24px]">
                {item.title}
              </div>
              <div className="text-[#A8A9AE] text-[17px] leading-[22px] flex items-center">
                <span className="mr-[4px]">
                  <img src="icon.svg" />
                </span>
                <span>{item.subtitle}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
      {draggingPosition != null && (
        <div
          className="divider"
          style={{
            top:
              draggingPosition * listRef.current.children[0].clientHeight +
              "px",
          }}
        />
      )}
      <DraggingItem
        isDragging={isDragging}
        item={draggingItem ?? items[0]}
        pos={pos}
      />
    </div>
  );
};

export default DraggableList;
